<?php

class PluginStsyncConfig extends CommonDBTM
{
    private static $CACHE = null;
    private static $ENC_KEY = 'ronics';
    private static $ENC_CIPHER = 'aes-256-cbc';

    const FILES_NAMES = [
        'glpi_url',
        'glpi_username',
        'glpi_password',
        'glpi_app_token',
        'glpi_category_id',
        'glpi_origem_requisicao_id',
        'glpi_origem_requerente_id',
        'glpi_entity',
        'glpi_trigger_categories',
        'glpi_trigger_requerentes',
        'glpi_trigger_fornecedores',
        'glpi_trigger_grupo_observador',
    ];

    function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        switch ($item::getType()) {
            case 'Config':
                return __('ST-Sync', 'stsync');
                break;
        }
        return '';
    }

    static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        switch ($item::getType()) {
            case 'Config':
                $config = new self();
                $config->show();
                break;
        }
    }

    static function getConfig($name, $defaultValue = null)
    {
        if (self::$CACHE === null) {
            $config = new self();

            $config->fields = array_merge($config->fields, Config::getConfigurationValues('stsync'));

            self::$CACHE = $config->fields;
        }

        if (isset(self::$CACHE[$name]) && self::$CACHE[$name] !== '') {
            return self::$CACHE[$name];
        }

        return $defaultValue;
    }

    public function show()
    {
        if (!Config::canView()) {
            return false;
        }

        $fields = [
            "glpi_url" => "http://1.2.3.4/glpi",
            "glpi_username" => "glpi",
            "glpi_password" => "",
            "glpi_app_token" => "",
            "glpi_category_id" => "",
            "glpi_origem_requisicao_id" => "",
            "glpi_origem_requerente_id" => "",
            "glpi_entity" => "",
            "glpi_trigger_categories" => "",
            "glpi_trigger_requerentes" => "",
            "glpi_trigger_fornecedores" => "",
            "glpi_trigger_grupo_observador" => "",
        ];

        $fields = array_merge($fields, Config::getConfigurationValues('stsync'));

        echo "
            <style>
                #stsync_tbody td {
                    padding-top: 10px;
                }
            </style>
        ";

        echo "<form id=\"stsync_form\" name='form' action=\"" . Toolbox::getItemTypeFormURL('Config') . "\" method='post'>";
        echo Html::hidden('config_context', ['value' => 'stsync']);
        echo Html::hidden('config_class', ['value' => __CLASS__]);
        echo Html::hidden('config_is_remove', ['value' => '0']);
        echo Html::hidden('update', ['value' => '1']);

        echo "<div class=\"center\">";
        echo "<table class=\"tab_cadre_fixe\">";
        echo "<tbody id=\"stsync_tbody\">";
        echo "<tr><th colspan=\"4\" >Servidor GLPI Remoto</th></tr>";

        echo "<tr><td></td></tr>";

        // GLPI API URL
        // echo "<tr class=\"tab_bg_1\"><td>GLPI api url<br>
        //     <b>IMPORTANTE: Ao alterar a url, o vínculo de tickets será perdido para a url previamente informad</b>
        // </td>";
        echo "<tr class=\"tab_bg_1\"><td>GLPI api url <b>(*)</b><br></td>";

        echo "<td>";
        echo Html::input("glpi_url", ['value' => $fields["glpi_url"], 'class' => 'form-control', 'required' => 'true']);
        echo "</td>";

        echo "</tr>";

        // GLPI USER LOGIN
        echo "<tr class=\"tab_bg_1\"><td>GLPI usuário <b>(*)</b></td>";

        echo "<td>";
        echo Html::input("glpi_username", ['value' => $fields["glpi_username"], 'class' => 'form-control', 'required' => 'true']);
        echo "</td>";

        echo "</tr>";

        // GLPI USER PASSWORD
        echo "<tr class=\"tab_bg_1\"><td>GLPI senha <b>(*)</b></td>";

        echo "<td>";
        echo Html::input("glpi_password", ['value' => "___senha salva___", "type" => "password", 'class' => 'form-control', 'required' => 'true']);
        echo "</td>";

        echo "</tr>";

        // GLPI APP TOKEN
        echo "<tr class=\"tab_bg_1\"><td>GLPI Token da aplicação (app_token) <b>(*)</b></td>";

        echo "<td>";
        echo Html::input("glpi_app_token", ['value' => "___campo criptografado___", "type" => "password", 'class' => 'form-control', 'required' => 'true']);
        echo "</td>";

        echo "</tr>";

        // GLPI CATEGORIA
        echo "<tr class=\"tab_bg_1\"><td>GLPI Categoria ID <b>(*)</b></td>";

        echo "<td>";
        echo Html::input("glpi_category_id", ['value' => $fields["glpi_category_id"], 'class' => 'form-control', 'required' => 'true']);
        echo "</td>";

        echo "</tr>";

        // GLPI ORIGEM REQUISICAO
        echo "<tr class=\"tab_bg_1\"><td>GLPI Origem da Requisição ID <b>(*)</b></td>";

        echo "<td>";
        echo Html::input("glpi_origem_requisicao_id", ['value' => $fields["glpi_origem_requisicao_id"], 'class' => 'form-control', 'required' => 'true']);
        echo "</td>";

        echo "</tr>";

        // GLPI REQUERENTE
        echo "<tr class=\"tab_bg_1\"><td>GLPI Requerente ID <b>(*)</b></td>";

        echo "<td>";
        echo Html::input("glpi_origem_requerente_id", ['value' => $fields["glpi_origem_requerente_id"], 'class' => 'form-control', 'required' => 'true']);
        echo "</td>";

        echo "</tr>";

        // GLPI ENTIDADE
        echo "<tr class=\"tab_bg_1\"><td>GLPI Entidade ID <b>(*)</b></td>";

        echo "<td>";
        echo Html::input("glpi_entity", ['value' => $fields["glpi_entity"], 'class' => 'form-control', 'required' => 'true']);
        echo "</td>";

        echo "</tr>";

        echo "<tr><td></td></tr>";

        echo "<tr><th colspan=\"4\" >Gatilhos de Integração</th></tr>";

        // GLPI GATILHO CATEGORIAS
        echo "<tr class=\"tab_bg_1\"><td>Categorias <br><b>( IDs separados por \";\" exemplo: 21;34;89 )</td>";

        echo "<td>";
        echo Html::input("glpi_trigger_categories", ['value' => $fields["glpi_trigger_categories"], 'class' => 'form-control']);
        echo "</td>";

        echo "</tr>";

        // GLPI GATILHO REQUERENTES
        echo "<tr class=\"tab_bg_1\"><td>Requerentes <br><b>( IDs separados por \";\" exemplo: 21;34;89 )</td>";

        echo "<td>";
        echo Html::input("glpi_trigger_requerentes", ['value' => $fields["glpi_trigger_requerentes"], 'class' => 'form-control']);
        echo "</td>";

        echo "</tr>";

        // GLPI GATILHO FORNECEDORES
        echo "<tr class=\"tab_bg_1\"><td>Fornecedores <br><b>( IDs separados por \";\" exemplo: 21;34;89 )</td>";

        echo "<td>";
        echo Html::input("glpi_trigger_fornecedores", ['value' => $fields["glpi_trigger_fornecedores"], 'class' => 'form-control']);
        echo "</td>";

        echo "</tr>";

        // GLPI GATILHO GRUPO FORNECEDOR
        echo "<tr class=\"tab_bg_1\"><td>Grupos Observador <br><b>( IDs separados por \";\" exemplo: 21;34;89 )</td>";

        echo "<td>";
        echo Html::input("glpi_trigger_grupo_observador", ['value' => $fields["glpi_trigger_grupo_observador"], 'class' => 'form-control']);
        echo "</td>";

        echo "</tr>";

        echo "<tr class='tab_bg_1'><td class='center' style=\"text-align: center;\" colspan='4'>";
        echo "<input type='submit' class='submit' value=\"" . __s('Salvar') . "\" >&nbsp;&nbsp;";
        echo "<input onclick=\"
            document.getElementsByName('config_is_remove')[0].value = 1; document.getElementById('stsync_form').submit();
        \" type='button' class='submit' value=\"" . __s('Remover vínculos de ticket') . "\" >";
        echo "</td></tr>\n";

        echo "</tbody>";
        echo "</table>";
        echo "</div>";

        Html::closeForm();
    }

    static function encrypt($data) {
        $encrypted = openssl_encrypt($data, self::$ENC_CIPHER, self::$ENC_KEY, 0);
        return base64_encode($encrypted);
    }
    
    static function decrypt($data) {
        $decoded = base64_decode($data);
        $decrypted = openssl_decrypt($decoded, self::$ENC_CIPHER, self::$ENC_KEY, 0);
        return is_bool($decrypted) ? $data : $decrypted;
    }

    static function configUpdate($input)
    {
        $old = Config::getConfigurationValues('stsync');
        $isRemove = isset($input['config_is_remove']) && $input['config_is_remove'] == '1';

        unset($input['config_is_remove']);

        // GLPI PASSWORD
        if ($input['glpi_password'] == '___senha salva___') {
            $input['glpi_password'] = $old['glpi_password'];
        } else if (
            (!empty($input['glpi_password']) && empty($old['glpi_password']))
            || (!empty($old['glpi_password']) && $input['glpi_password'] != $old['glpi_password'])
        ) {
            $input['glpi_password'] = self::encrypt($input['glpi_password']);
        }

        // GLPI APP TOKEN
        if ($input['glpi_app_token'] == '___campo criptografado___') {
            $input['glpi_app_token'] = $old['glpi_app_token'];
        } else if (
            (!empty($input['glpi_app_token']) && empty($old['glpi_app_token']))
            || (!empty($old['glpi_app_token']) && $input['glpi_app_token'] != $old['glpi_app_token'])
        ) {
            $input['glpi_app_token'] = self::encrypt($input['glpi_app_token']);
        }

        $input['glpi_url'] = (substr($input['glpi_url'], -1) === "/") ? rtrim($input['glpi_url'], "/") : $input['glpi_url'];
        
        if ($isRemove /* $old['glpi_url'] != $input['glpi_url'] */) {
            self::clean_fields();

            return $old;
        }
          
        return $input;
    }

    static function create_fields()
    {
        global $DB;

        $query = "SHOW COLUMNS FROM glpi_tickets LIKE 'stsync_id'";
        $result = $DB->query($query);

        if (!$DB->numrows($result)) {
            $query = "ALTER TABLE glpi_tickets ADD stsync_id INT(11)";
            $DB->query($query);
        }

        $query = "SHOW COLUMNS FROM glpi_itilfollowups LIKE 'stsync_id'";
        $result = $DB->query($query);

        if (!$DB->numrows($result)) {
            $query = "ALTER TABLE glpi_itilfollowups ADD stsync_id INT(11)";
            $DB->query($query);
        }

        $query = "SHOW COLUMNS FROM glpi_itilsolutions LIKE 'stsync_id'";
        $result = $DB->query($query);

        if (!$DB->numrows($result)) {
            $query = "ALTER TABLE glpi_itilsolutions ADD stsync_id INT(11)";
            $DB->query($query);
        }

        return true;
    }

    static function drop_fields()
    {
        global $DB;

        $query = "SHOW COLUMNS FROM glpi_tickets LIKE 'stsync_id'";
        $result = $DB->query($query);

        if ($DB->numrows($result)) {
            $query = "ALTER TABLE glpi_tickets DROP COLUMN stsync_id";
            $DB->query($query);
        }

        $query = "SHOW COLUMNS FROM glpi_itilfollowups LIKE 'stsync_id'";
        $result = $DB->query($query);

        if ($DB->numrows($result)) {
            $query = "ALTER TABLE glpi_itilfollowups DROP COLUMN stsync_id";
            $DB->query($query);
        }

        $query = "SHOW COLUMNS FROM glpi_itilsolutions LIKE 'stsync_id'";
        $result = $DB->query($query);

        if ($DB->numrows($result)) {
            $query = "ALTER TABLE glpi_itilsolutions DROP COLUMN stsync_id";
            $DB->query($query);
        }

        return true;
    }

    static function clean_fields()
    {
        global $DB;

        $DB->query("UPDATE glpi_tickets SET stsync_id = NULL WHERE stsync_id IS NOT NULL");

        $DB->query("UPDATE glpi_itilfollowups SET stsync_id = NULL WHERE stsync_id IS NOT NULL");

        $DB->query("UPDATE glpi_itilsolutions SET stsync_id = NULL WHERE stsync_id IS NOT NULL");

        return true;
    }

    static function checkAllValuesExcept(string $keyExcept, array $fields)
    {
        foreach (self::FILES_NAMES as $key => $value) {
            if ($value != $keyExcept && !empty($fields[$value])) return true;
        }

        return false;
    }

    static public function startsWith($haystack, $needle)
    {
        $length = strlen($needle);
        return (substr($haystack, 0, $length) === $needle);
    }
}

<?php

define('GLPI_ROOT', '../../..');
require_once(GLPI_ROOT . '/inc/includes.php');

// Check if plugin is activated...
$plugin = new Plugin();
if (!$plugin->isInstalled('stsync') || !$plugin->isActivated('stsync')) {
   return false;
}

Html::redirect($CFG_GLPI["root_doc"].
   '/front/config.form.php?forcetab=PluginStsyncConfig$1');

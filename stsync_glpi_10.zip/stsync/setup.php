<?php

define('PLUGIN_STSYNC_API_VERSION', '1.0.0');

$folder = basename(dirname(__FILE__));

if ($folder !== "stsync") {
   $msg = sprintf("Por favor, renomeie a pasta dso plugin de \"%s\" para \"stsync\"", $folder);
   Session::addMessageAfterRedirect($msg, true, ERROR);
}

function plugin_init_stsync() {
   global $PLUGIN_HOOKS;

   $PLUGIN_HOOKS['csrf_compliant']['stsync'] = true;

   $plugin = new Plugin();

   if ($plugin->isActivated("stsync")) {
      $PLUGIN_HOOKS['config_page']['stsync'] = 'front/config.form.php';

      $PLUGIN_HOOKS['item_add']['stsync'] = [
         'Ticket'  => 'plugin_stsync_ticket_add',
         'ITILFollowup'  => 'plugin_stsync_ticketfollow_add',
         'TicketTask'  => 'plugin_stsync_tickettask_add',
         'ITILSolution'  => 'plugin_stsync_ticketsolution_add',
      ];

      // $PLUGIN_HOOKS['item_update']['stsync'] = [
      //    'Ticket'  => 'plugin_stsync_ticket_update',
      //    'ITILFollowup'  => 'plugin_stsync_ticketfollow_update'
      // ];

      // $PLUGIN_HOOKS['item_delete']['stsync'] = [
      //    'Ticket'  => 'plugin_stsync_ticket_delete',
      //    'ITILFollowup'  => 'plugin_stsync_ticketfollow_delete'
      // ];

      // $PLUGIN_HOOKS['item_purge']['stsync'] = [
      //    'Ticket'  => 'plugin_stsync_ticket_purge',
      //    'ITILFollowup'  => 'plugin_stsync_ticketfollow_purge'
      // ];

      Plugin::registerClass(
         'PluginStsyncConfig', [
            'addtabon' => [
               'Config'
            ]
         ]
      );
   }
}

function plugin_version_stsync() {
   return [
      'name'           => 'ST-Sync',
      'version'        =>  PLUGIN_STSYNC_API_VERSION,
     'author'         => 'Service TIC <a href="https://github.com/serviceticst/st-sync/releases"></a>',
      'license'        => 'GLPv3',
      'homepage'       => 'https://github.com/serviceticst/st-sync/releases',
      'requirements'   => [
        'glpi'   => [
           'min' => '10.0.0',
        ],
        'php'    => [
           'min' => '7.0'
        ]
     ]
   ];
}

function plugin_stsync_check_prerequisites() {
   return true;
}

function plugin_stsync_check_config($verbose = false) {
   return true;
}

function plugin_stsync_options() {
   return [
      Plugin::OPTION_AUTOINSTALL_DISABLED => true,
   ];
}